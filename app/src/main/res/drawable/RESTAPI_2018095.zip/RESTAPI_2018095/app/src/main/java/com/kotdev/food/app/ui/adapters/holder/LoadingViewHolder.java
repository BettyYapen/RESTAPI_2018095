package com.kotdev.food.app.ui.adapters.holder;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class LoadingViewHolder extends RecyclerView.ViewHolder {

    public LoadingViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
