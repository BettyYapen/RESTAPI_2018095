package com.kotdev.food.app.ui.adapters.holder;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SearchExhaustedViewHolder extends RecyclerView.ViewHolder {

    public SearchExhaustedViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
